#######################
License and Legal Info
#######################
 
Copyright Notice and License Terms for h5serv Software Service, Libraries and Utilities
---------------------------------------------------------------------------------------

h5serv (HDF5 REST Server) Service, Libraries and Utilities

Copyright (c) |copyright|

All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted for any purpose (including commercial purposes) 
provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, 
   this list of conditions, and the following disclaimer in the documentation 
   and/or materials provided with the distribution.

3. In addition, redistributions of modified forms of the source or binary 
   code must carry prominent notices stating that the original code was 
   changed and the date of the change.

4. All publications or advertising materials mentioning features or use of 
   this software are asked, but not required, to acknowledge that it was 
   developed by The HDF Group and credit the contributors.

5. Neither the name of The HDF Group, nor the name of any Contributor may 
   be used to endorse or promote products derived from this software 
   without specific prior written permission from The HDF Group or the 
   Contributor, respectively.

DISCLAIMER: 
THIS SOFTWARE IS PROVIDED BY THE HDF GROUP AND THE CONTRIBUTORS 
"AS IS" WITH NO WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED.  In no 
event shall The HDF Group or the Contributors be liable for any damages 
suffered by the users arising out of the use of this software, even if 
advised of the possibility of such damage. 

